class Person1 < ApplicationRecord
end
